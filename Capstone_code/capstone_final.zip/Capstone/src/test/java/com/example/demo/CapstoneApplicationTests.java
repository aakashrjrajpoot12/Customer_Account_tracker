package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest                                                             //to spin up the container
class CapstoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
