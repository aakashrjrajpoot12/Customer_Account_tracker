package com.example.demo.exception;

public class ResourceNotFoundException extends Exception {                                     //Exception is in-built library which we are using as exception.class

                                                                                              //this class implementation is inside ResourceNotFoundException


public ResourceNotFoundException() {
super();

}

public ResourceNotFoundException(String message) {
	super(message);
	// TODO Auto-generated constructor stub
}
}













